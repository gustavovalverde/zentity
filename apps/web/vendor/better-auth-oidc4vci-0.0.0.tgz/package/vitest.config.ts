import { defineProject } from "vitest/config";

export default defineProject({
	ssr: {
		resolve: {
			conditions: ["dev-source"],
		},
	},
});
