import { extendOAuthProvider } from "@better-auth/oauth-provider";
import type { BetterAuthPlugin } from "better-auth";
import {
	createCredentialEndpoint,
	createCredentialOfferEndpoint,
	createDeferredCredentialEndpoint,
	createGetCredentialOfferEndpoint,
	createMetadataEndpoints,
	createNonceEndpoint,
	createStatusListEndpoint,
	createUpdateCredentialStatusEndpoint,
} from "./endpoints";
import {
	createPreAuthorizedCodeHandler,
	PRE_AUTH_GRANT_TYPE,
} from "./grant-handler";
import { schema } from "./schema";
import type { Oidc4vciOptions } from "./types";

declare module "@better-auth/core" {
	interface BetterAuthPluginRegistry<AuthOptions, Options> {
		oidc4vci: {
			creator: typeof oidc4vci;
		};
	}
}

export { schema } from "./schema";
export * from "./types";

export function oidc4vci(options: Oidc4vciOptions) {
	const { getCredentialIssuerMetadata, wellKnownAliasEndpoints } =
		createMetadataEndpoints(options);

	return {
		id: "oidc4vci",
		schema,
		options,
		init(ctx) {
			// The pre-authorized_code grant requires oauth-provider. A metadata-only
			// deployment (no oauth-provider) still serves the issuer well-known
			// documents, so register the grant only when the provider is present.
			if (!ctx.getPlugin("oauth-provider")) {
				return;
			}
			extendOAuthProvider(ctx, {
				grants: {
					[PRE_AUTH_GRANT_TYPE]: createPreAuthorizedCodeHandler(),
				},
			});
		},
		endpoints: {
			/**
			 * OIDC4VCI Credential Issuer Metadata.
			 *
			 * Serve this at `/.well-known/openid-credential-issuer` via your
			 * framework's routing (e.g. a Next.js route file) when BetterAuth
			 * is mounted under a basePath (e.g. /api/auth).
			 */
			getCredentialIssuerMetadata,
			...wellKnownAliasEndpoints,

			/**
			 * OID4VCI nonce endpoint (Section 7).
			 *
			 * Used to obtain a `c_nonce` for proof binding.
			 */
			nonce: createNonceEndpoint(),

			/**
			 * OAuth Status List endpoint (SD-JWT VC status list).
			 */
			statusList: createStatusListEndpoint(options),

			/**
			 * Issuer-admin endpoint to create a credential offer for a user.
			 *
			 * v1: requires an authenticated session (issuer operator) to create offers.
			 */
			createCredentialOffer: createCredentialOfferEndpoint(options),

			/**
			 * OIDC4VCI credential offer URI resolution.
			 */
			getCredentialOffer: createGetCredentialOfferEndpoint(options),

			/**
			 * Issuer-admin endpoint to update credential status (revocation).
			 */
			updateCredentialStatus: createUpdateCredentialStatusEndpoint(),

			/**
			 * OIDC4VCI credential endpoint.
			 *
			 * v1: requires a JWT access token audience bound to this endpoint and a proof.jwt binding to c_nonce.
			 */
			credential: createCredentialEndpoint(options),

			/**
			 * OIDC4VCI deferred credential endpoint.
			 */
			deferredCredential: createDeferredCredentialEndpoint(options),
		},
	} satisfies BetterAuthPlugin;
}
